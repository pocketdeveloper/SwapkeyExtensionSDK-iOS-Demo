//
//  SwapkeyExtensionSDK.h
//  SwapkeyExtensionSDK
//
//  Created by Carolina Franco on 8/8/18.
//  Copyright © 2018 Carolina Franco. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwapkeyExtensionSDK.
FOUNDATION_EXPORT double SwapkeyExtensionSDKVersionNumber;

//! Project version string for SwapkeyExtensionSDK.
FOUNDATION_EXPORT const unsigned char SwapkeyExtensionSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwapkeyExtensionSDK/PublicHeader.h>


